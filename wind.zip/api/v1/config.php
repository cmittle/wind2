<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'corysc5_wind2');
define('DB_PASSWORD', 'cm259925');
define ('DB_HOST', 'localhost');
//have to set up database connection in Netbeans as well as add house IP 
//address to "remote MySQL on hosting cpanel
//This still doesn't connect from NetBeans, have to figure this part out...
define('DB_NAME', 'corysc5_wind2');

?>
