<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'corysc5_wind2');
define('DB_PASSWORD', 'cm259925');
define ('DB_HOST', 'localhost');
//define('DB_HOST', '205.134.253.65');
define('DB_NAME', 'corysc5_wind2');

?>
